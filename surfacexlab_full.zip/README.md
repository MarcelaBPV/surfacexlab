# SurfaceXLab

Plataforma genérica para **análise de superfície de materiais**, integrada com Streamlit e Supabase.

- **Aba 1 — Raman**  
  Processamento de espectros Raman com:
  - Subtração de substrato
  - Correção de baseline (ASLS)
  - Suavização Savitzky–Golay
  - Detecção de picos e ajuste Lorentziano
  - Download de espectro corrigido e picos
  - Salvamento opcional no Supabase

- **Aba 2 — Tensiometria**  
  Leitura de logs de ângulo de contato (tempo × ângulo médio), ajuste polinomial, cálculo de dθ/dt e razão cos(γ).

- **Aba 3 — Resistividade (4 pontas)**  
  Leitura de curvas I×V, regressão linear, cálculo de resistência, resistividade, condutividade e classificação de material.

- **Aba 4 — Otimização ML**  
  Treino rápido de modelos Random Forest (regressão ou classificação) a partir de qualquer CSV (Raman, tensiometria, resistividade, etc.).

## Estrutura dos arquivos

- `app.py` — App principal do Streamlit, com as quatro abas.
- `raman_tab.py` — Aba Raman (usa `raman_processing.py`).
- `tensiometria_tab.py` — Aba Tensiometria (usa `tensiometria.py`).
- `resistividade_tab.py` — Aba Resistividade (usa `resistividade.py`).
- `ml_tab.py` — Aba de Otimização ML.
- `raman_processing.py` — Pipeline completo de processamento Raman.
- `tensiometria.py` — Função de processamento de ângulo de contato.
- `resistividade.py` — Função de processamento de resistividade.

## Como rodar localmente

1. Crie um ambiente virtual (opcional, mas recomendado):

   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate   # Windows
   ```

2. Instale as dependências:

   ```bash
   pip install -r requirements.txt
   ```

3. Execute o app:

   ```bash
   streamlit run app.py
   ```

4. Coloque o arquivo da logo (por exemplo  
   `SurfaceXLab Lettermark Logo - High-Tech Aesthetic.png`) na mesma pasta que o `app.py`
   ou ajuste o caminho em `st.image(...)`.

## Configuração do Supabase

Para habilitar salvamento no banco:

1. Crie um projeto no [Supabase](https://supabase.com/).
2. Copie a URL do projeto e a chave **anon** (ou service_role).
3. Crie o arquivo `.streamlit/secrets.toml` com:

   ```toml
   SUPABASE_URL = "https://SEU-PROJETO.supabase.co"
   SUPABASE_KEY = "SUA_CHAVE_ANON"
   ```

4. Crie as tabelas necessárias (exemplo de esquema):

   ```sql
   -- Tabelas Raman
   create table if not exists public.raman_measurements (
     id bigint generated always as identity primary key,
     sample_name text not null,
     material text,
     substrate_type text,
     notes text,
     created_at timestamptz default now()
   );

   create table if not exists public.raman_spectra (
     id bigint generated always as identity primary key,
     measurement_id bigint references public.raman_measurements(id) on delete cascade,
     wavenumber_cm1 double precision not null,
     intensity_norm double precision not null
   );

   create table if not exists public.raman_peaks (
     id bigint generated always as identity primary key,
     measurement_id bigint references public.raman_measurements(id) on delete cascade,
     peak_cm1 double precision,
     intensity double precision,
     prominence double precision,
     index integer,
     fit_amp double precision,
     fit_cen double precision,
     fit_width double precision,
     fit_fwhm double precision,
     fit_offset double precision,
     fit_amp_raw double precision,
     fit_height double precision
   );

   -- Tabelas Tensiometria
   create table if not exists public.tensiometry_summary (
     id bigint generated always as identity primary key,
     sample_name text not null,
     material text,
     gamma_ratio double precision,
     poly_order integer,
     poly_coef jsonb,
     notes text,
     created_at timestamptz default now()
   );

   create table if not exists public.tensiometry_data (
     id bigint generated always as identity primary key,
     tensiometry_id bigint references public.tensiometry_summary(id) on delete cascade,
     t_seconds double precision,
     angle_mean_deg double precision,
     dtheta_dt double precision
   );

   -- Tabelas Resistividade
   create table if not exists public.resistivity_summary (
     id bigint generated always as identity primary key,
     sample_name text not null,
     material text,
     mode text,
     thickness_m double precision,
     R_ohm double precision,
     rho_ohm_m double precision,
     sigma_S_m double precision,
     class_label text,
     r2 double precision,
     notes text,
     created_at timestamptz default now()
   );

   create table if not exists public.resistivity_data (
     id bigint generated always as identity primary key,
     resistivity_id bigint references public.resistivity_summary(id) on delete cascade,
     current_a double precision,
     voltage_v double precision
   );
   ```

Ajuste os nomes dos campos conforme sua necessidade.

## Propriedade Intelectual

Este código e a concepção da plataforma SurfaceXLab são de propriedade de:

**Marcela Veiga**

- © 2025 Marcela Veiga — Todos os direitos reservados.  
- É proibida a cópia, redistribuição ou uso comercial deste código sem autorização
  prévia e expressa da autora.

O repositório pode ser utilizado apenas para fins acadêmicos, de pesquisa e
demonstração de conceito (MVP), salvo autorização em contrário.
